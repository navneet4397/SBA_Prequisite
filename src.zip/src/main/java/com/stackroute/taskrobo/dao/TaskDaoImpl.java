package com.stackroute.taskrobo.dao;

import com.stackroute.taskrobo.model.Category;
import com.stackroute.taskrobo.model.Task;

import org.h2.engine.Session;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.SharedSessionContract;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Objects;

/*
 * This class is implementing the TaskDao interface. This class has to be annotated with following annotation
 * @Repository - is an annotation that marks the specific class as a Data Access Object, thus
 * 				 clarifying it's role.
 * @Transactional - The transactional annotation itself defines the scope of a single database
 * 					transaction. The database transaction happens inside the scope of a persistence
 * 					context.
 *
 */
@Repository
public class TaskDaoImpl implements TaskDao {

	
	
	
	/*
	 * Constructor based Autowiring should be implemented for the SessionFactory
	 * Please note that we should not create any object using the new keyword.
	 */

	@Autowired
	private SessionFactory sessionFactory;

	@Autowired
	public TaskDaoImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	/*
	 * Save the task in the database(task) table.
	 */

	@Override
	public boolean saveTask(Task task) {
		org.hibernate.Session session = (org.hibernate.Session) sessionFactory.getCurrentSession();
		session.persist(task);
		Task taask=session.get(Task.class,task.getTaskId());
		if(Objects.nonNull(taask) || task.getCategory().equals(taask.getCategory())) {
			return true;
		}
		return false;
	}

	/*
	 * Remove the task from the database(task) table.
	 */

	@Override
	public boolean deleteTask(int taskId) {
		org.hibernate.Session session = (org.hibernate.Session) sessionFactory.getCurrentSession();
		if(!Objects.nonNull(session.get(Task.class,taskId))) {
			return false;
		}
		
		String sql1="delete Task where taskId="+taskId;
		Query query=session.createQuery(sql1);
		if(query.executeUpdate()>0) {return true;}
		return false;
	}

	/*
	 * Retrieve all existing tasks
	 */

	@SuppressWarnings("unchecked")
	@Override
	public List<Task> getAllTasks() {
		Session session = (Session) sessionFactory.openSession();
		org.hibernate.Session session1 = (org.hibernate.Session) sessionFactory.getCurrentSession();
		String sql1="from Task";
		Query query=session1.createQuery(sql1);
		List<Task> taskList=query.getResultList();
		if(Objects.nonNull(taskList)) {
			return taskList;
		}
		else {
			return null;
		}
	}

	/*
	 * Retrieve specific task from the database
	 */

	@Override
	public Task getTaskById(int taskId) {
		org.hibernate.Session session = (org.hibernate.Session) sessionFactory.getCurrentSession();
		String sql1="from Task wheres taskId="+taskId;
		Query query=session.createQuery(sql1);
		Task task=(Task) query.getSingleResult();
		if(Objects.nonNull(task)) {
			return task;
		}
		else {
			return null;
		}
	}

	/* Update existing task */

	@Override
	public boolean updateTask(Task task) {
		org.hibernate.Session session = (org.hibernate.Session) sessionFactory.getCurrentSession();
		Task taskfetched=session.get(Task.class, task.getTaskId());
		
		if(Objects.nonNull(taskfetched)) {
			taskfetched.setCategory(task.getCategory());
			taskfetched.setTaskContent(task.getTaskContent());
			taskfetched.setTaskStatus(task.getTaskStatus());
			taskfetched.setTaskTitle(task.getTaskTitle());
			session.saveOrUpdate(taskfetched);
			Category cat=session.get(Task.class, task.getTaskId()).getCategory();
			if(cat.equals(task.getCategory()))
				return true;
			else
				return false;
		}
		else {
			return false;
		}
	}

}
