package com.stackroute.taskrobo.exception;


public class CategoryDoesNotExistException extends Exception {
    public CategoryDoesNotExistException(String message) {
        super(message);
    }

}
