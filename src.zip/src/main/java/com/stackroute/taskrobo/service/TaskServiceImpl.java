package com.stackroute.taskrobo.service;

import com.stackroute.taskrobo.dao.TaskDao;
import com.stackroute.taskrobo.exception.TaskAlreadyExistException;
import com.stackroute.taskrobo.exception.TaskDoesNotExistException;
import com.stackroute.taskrobo.model.Task;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.util.List;

/*
 * Service classes are used here to implement additional business logic/validation
 * This class has to be annotated with @Service annotation.
 */

@PropertySource("classpath:application.properties")
@Service
public class TaskServiceImpl implements TaskService {
	/*
	 * Constructor based Autowiring should be implemented for the TaskDao and
	 * Environment.Please note that we should not create any object using the new
	 * keyword.
	 */

	private TaskDao taskDAO;

	@Autowired
	public TaskServiceImpl(TaskDao taskDAO) {
		super();
		this.taskDAO = taskDAO;
	}

	private Environment environment;

	@Autowired
	public TaskServiceImpl(Environment environment) {
		super();
		this.environment = environment;
	}

	public TaskServiceImpl() {
	}

	/*
	 * Do not hardcode exception message. Get it from application.properties using
	 * environment variables.
	 */
	/*
	 * This method should be used to save a new task.
	 */
	@Override
	@Value("${taskAlreadyExistException.message}")
	public boolean saveTask(Task task) throws TaskAlreadyExistException {
		taskDAO.saveTask(task);
		return false;
	}

	/*
	 * This method should be used to update a existing task.
	 */

	@Override
	@Value("${taskDoesNotExistException.message}")
	public boolean updateTask(Task task) throws TaskDoesNotExistException {
		taskDAO.updateTask(task);
		return false;
	}

	/*
	 * This method should be used to get a task by taskId.
	 */

	@Override
	@Value("${taskDoesNotExistException.message}")
	public Task getTaskById(int taskId) throws TaskDoesNotExistException {
		return taskDAO.getTaskById(taskId);
	}

	/*
	 * This method should be used to get all the tasks.
	 */

	@Override
	public List<Task> getAllTasks() {
		return taskDAO.getAllTasks();
	}

	/* This method should be used to delete an existing task. */
	@Override
	@Value("${taskDoesNotExistException.message}")
	public boolean deleteTask(int taskId) throws TaskDoesNotExistException {
		return taskDAO.deleteTask(taskId);
	}
}
