package com.stackroute.taskrobo.service;

import com.stackroute.taskrobo.exception.CategoryAlreadyExistException;
import com.stackroute.taskrobo.exception.CategoryDoesNotExistException;
import com.stackroute.taskrobo.model.Category;
import com.stackroute.taskrobo.model.Task;

import java.util.List;

import javax.transaction.Transactional;

@Transactional
public interface CategoryService {
    boolean saveCategory(Category category) throws CategoryAlreadyExistException;

    Category getCategoryByTitle(String categoryTitle) throws CategoryDoesNotExistException;

    List<Task> getAllTasks(String categoryTitle) throws CategoryDoesNotExistException;

    List<Category> getAllCategories();

    boolean deleteCategory(String categoryTitle) throws CategoryDoesNotExistException;
}
