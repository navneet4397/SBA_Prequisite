package com.stackroute.taskrobo.dao;

import com.stackroute.taskrobo.config.SpringRootConfig;
import com.stackroute.taskrobo.model.Category;
import org.hibernate.SessionFactory;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.Query;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
@Transactional
@ContextConfiguration(classes = {SpringRootConfig.class})
public class CategoryDaoImplIntegrationTest {
    @Autowired
    private SessionFactory sessionFactory;
    private CategoryDaoImpl categoryDao;

    private static Category category;
    private static final String MESSAGE_ONE = "Given Category to be saved should return true";
    private static final String MESSAGE_TWO = "Given Category cannot be saved because Category with same categoryTitle already exists";
    private static final String MESSAGE_THREE = "Given valid categoryTitle should return category object";
    private static final String MESSAGE_FOUR = "Given invalid categoryTitle to search should return null";
    private static final String MESSAGE_FIVE = "Given valid categoryTitle should delete the record and return true ";
    private static final String MESSAGE_SIX = "Given invalid categoryTitle should not delete the record and return false ";
    private static final String MESSAGE_NINE = "Should return all the category";


    private static ApplicationContext context;


    @BeforeAll
    public static void initContext() {
        context = new ClassPathXmlApplicationContext("beans.xml");
    }

    @BeforeEach
    public void setUp() {
        context = new ClassPathXmlApplicationContext("beans.xml");
        category = (Category) context.getBean("category");
        categoryDao = new CategoryDaoImpl(sessionFactory);

    }

    @AfterEach
    public void tearDown() {
        categoryDao = null;
        Query query = sessionFactory.getCurrentSession().createQuery("Delete from Category");
        query.executeUpdate();

    }

    @Test
    @Order(1)
    public void givenValidCategoryDataWhenSavedThenReturnTrue() throws Exception {
        assertTrue(categoryDao.saveCategory(category), MESSAGE_ONE);
    }

    @Test
    @Order(1)
    public void givenInValidCategoryDataWhenSavedThenReturnFalse() throws Exception {
        assertTrue(categoryDao.saveCategory(category), MESSAGE_ONE);
        Category newCategory = new Category("Kubernetes Deployment");
        assertFalse(categoryDao.saveCategory(newCategory), MESSAGE_TWO);
    }

    @Test
    @Rollback(true)
    @Order(2)
    public void givenValidCategoryTitleThenReturnCategory() {
        assertTrue(categoryDao.saveCategory(category), MESSAGE_ONE);
        assertEquals(category.toString(), categoryDao.getCategoryByTitle("Kubernetes Deployment").toString(), MESSAGE_THREE);

    }

    @Test
    @Rollback(true)
    @Order(2)
    public void givenInvalidCategoryTitleThenReturnNull() {
        assertNull(categoryDao.getCategoryByTitle("Spring Mvc"), MESSAGE_FOUR);
    }

    @Test
    @Rollback(true)
    @Order(3)
    public void givenValidCategoryTitleWhenDeletedThenReturnTrue() {
        assertTrue(categoryDao.saveCategory(category), MESSAGE_ONE);
        assertTrue(categoryDao.deleteCategory("Kubernetes Deployment"), MESSAGE_FIVE);
    }

    @Test
    @Rollback(true)
    @Order(3)
    public void givenInValidTaskIdWhenDeletedThenReturnFalse() {
        assertFalse(categoryDao.deleteCategory("Spring Mvc"), MESSAGE_SIX);
    }


    @Test
    @Order(4)
    public void givenCategoryDataWhenSavedThenReturnAllTasks() throws Exception {
        assertTrue(categoryDao.saveCategory(category), MESSAGE_ONE);
        Category newCategory = new Category("Spring Boot Tasks");
        assertTrue(categoryDao.saveCategory(newCategory), MESSAGE_ONE);
        List<Category> categories = categoryDao.getAllCategories();
        assertEquals("Spring Boot Tasks", categories.get(1).getCategoryTitle(), MESSAGE_NINE);
    }
}
